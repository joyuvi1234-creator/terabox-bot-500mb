import asyncio
import os
import re
import tempfile
from urllib.parse import quote_plus, urlparse, unquote

import requests
from pyrogram import Client, filters
from pyrogram.types import Message

from config import TERABOX_API_DOWNLOAD_ENDPOINT, MAX_FILE_SIZE_MB

TERABOX_LINK = re.compile(
    r"https?://(?:www\\.)?[^\\s/]*terabox[^\\s/]*/[^\\s]+",
    re.IGNORECASE
)
TIMEOUT = 45
MAX_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024

def resolve_link(share_url: str) -> dict:
    endpoint = f"{TERABOX_API_DOWNLOAD_ENDPOINT}?url={quote_plus(share_url)}"
    response = requests.get(endpoint, timeout=TIMEOUT)
    response.raise_for_status()
    data = response.json()
    if not data.get("success"):
        raise ValueError(data.get("message") or data.get("error") or "The download service could not resolve this link.")

    qualities = data.get("qualities") or {}
    best = data.get("best_quality")
    download_url = qualities.get(best) if best else None
    if not download_url and qualities:
        download_url = next(iter(qualities.values()))
    download_url = download_url or data.get("media_url") or data.get("direct_download_url")
    if not download_url:
        raise ValueError("The API response did not contain a downloadable file URL.")

    filename = data.get("filename") or unquote(urlparse(download_url).path.rsplit("/", 1)[-1]) or "terabox_file"
    filename = os.path.basename(filename).replace("\\", "_").replace("/", "_")
    return {"url": download_url, "filename": filename}

def download_file(url: str, target: str) -> int:
    total = 0
    with requests.get(url, stream=True, timeout=TIMEOUT) as response:
        response.raise_for_status()
        length = int(response.headers.get("content-length") or 0)
        if length and length > MAX_BYTES:
            raise ValueError(f"File is larger than this bot’s configured {MAX_FILE_SIZE_MB} MB limit.")
        with open(target, "wb") as output:
            for chunk in response.iter_content(chunk_size=1024 * 256):
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_BYTES:
                    raise ValueError(f"File is larger than this bot’s configured {MAX_FILE_SIZE_MB} MB limit.")
                output.write(chunk)
    return total

@Client.on_message(filters.text & filters.private)
async def terabox_handler(client: Client, message: Message):
    text = message.text or ""
    match = TERABOX_LINK.search(text)
    if not match:
        return

    share_url = match.group(0).rstrip(").,]")
    status = await message.reply_text("⏳ Checking the public TeraBox link…")
    temp_path = None
    try:
        info = await asyncio.to_thread(resolve_link, share_url)
        with tempfile.NamedTemporaryFile(prefix="terabox_", delete=False) as temp:
            temp_path = temp.name
        await status.edit_text("⬇️ Downloading the file…")
        size = await asyncio.to_thread(download_file, info["url"], temp_path)
        await status.edit_text("📤 Uploading to Telegram…")
        caption = f"Downloaded from your public TeraBox link · {size / (1024 * 1024):.1f} MB"
        await message.reply_document(
            document=temp_path,
            file_name=info["filename"],
            caption=caption
        )
        await status.delete()
    except Exception as exc:
        await status.edit_text(f"❌ Could not download this link: {str(exc)[:700]}")
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
