from pyrogram import Client, filters
from pyrogram.types import Message

@Client.on_message(filters.command("start"))
async def start_command(client: Client, message: Message):
    await message.reply_text(
        "Hi! Send me a **public TeraBox share link** and I’ll try to fetch the file.\n\n"
        "Private links and links requiring an account are not supported. "
        "Large files may exceed Telegram’s upload limit."
    )
