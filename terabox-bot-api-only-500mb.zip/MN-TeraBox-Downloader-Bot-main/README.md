# TeraBox Telegram Bot — API-only test build

This build is adapted from the MN-BOTS project and retains its upstream LICENSE and attribution.
It uses a configurable third-party resolver API only. It does **not** scrape TeraBox pages,
does not contain a TeraBox cookie, and does not use MongoDB or verification.

## Required environment variables
- `TOKEN`: Telegram bot token from BotFather
- `API_ID` and `API_HASH`: Telegram API credentials from https://my.telegram.org
- `OWNER`: optional Telegram numeric user ID for startup notification
- `TERABOX_API_DOWNLOAD_ENDPOINT`: resolver API endpoint (default is the endpoint used by the upstream project)
- `MAX_FILE_SIZE_MB`: local safety limit (default 500 MB)

Copy `.env.example` to `.env` for local testing, or set the variables in your host's environment settings.
Never publish `.env` or share your bot token.

## Run
```bash
pip install -r requirements.txt
python bot.py
```

Send `/start`, then send a **public** TeraBox share link in a private chat with the bot.

## Important limitations
- The external resolver API is operated by a third party. Its uptime, privacy practices, free access,
  and response format are not guaranteed by this project. This build has not been live-tested with
  a sample public share link.
- Only public links that the resolver can access are supported. It cannot access private/account-only
  shares or bypass permissions.
- The bot downloads to temporary disk and removes the temporary file after upload.
- The configured download ceiling is 500 MB. **This does not guarantee Telegram can upload a 500 MB file:**
  the standard hosted Telegram Bot API has a much lower upload limit. To send files this large, the bot
  must be configured to use a self-hosted Telegram Local Bot API Server, and the hosting disk/RAM/network
  must also support the file size. Without that setup, uploads above Telegram's standard limit may fail.
- A free hosting service may sleep, expire, or impose storage/runtime limits.
- Respect TeraBox and Telegram terms and the rights of the file owner.

Original project credit: https://github.com/MN-BOTS
